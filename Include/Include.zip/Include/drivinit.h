/*+@@file@@----------------------------------------------------------------*//*!
 \file		drivinit.h
 \par Description 
            Extension and update of headers for PellesC compiler suite.
 \par Project: 
            PellesC Headers extension
 \date		Created  on Wed Jul  6 14:33:20 2016
 \date		Modified on Wed Jul  6 14:33:20 2016
 \author	frankie
\*//*-@@file@@----------------------------------------------------------------*/

#if __POCC__ >= 500
#pragma once
#endif
