/*+@@file@@----------------------------------------------------------------*//*!
 \file		bitsmsg.h
 \par Description 
            Extension and update of headers for PellesC compiler suite.
 \par Project: 
            PellesC Headers extension
 \date		Created  on Sat Jul  2 20:57:18 2016
 \date		Modified on Sat Jul  2 20:57:18 2016
 \author	frankie
\*//*-@@file@@----------------------------------------------------------------*/

#ifndef _BGCPYMSG_
#define _BGCPYMSG_
#if __POCC__ >= 500
#pragma once
#endif
#define BG_E_NOT_FOUND                   0x80200001L
#define BG_E_INVALID_STATE               0x80200002L
#define BG_E_EMPTY                       0x80200003L
#define BG_E_FILE_NOT_AVAILABLE          0x80200004L
#define BG_E_PROTOCOL_NOT_AVAILABLE      0x80200005L
#define BG_S_ERROR_CONTEXT_NONE          0x00200006L
#define BG_E_ERROR_CONTEXT_UNKNOWN       0x80200007L
#define BG_E_ERROR_CONTEXT_GENERAL_QUEUE_MANAGER 0x80200008L
#define BG_E_ERROR_CONTEXT_LOCAL_FILE    0x80200009L
#define BG_E_ERROR_CONTEXT_REMOTE_FILE   0x8020000AL
#define BG_E_ERROR_CONTEXT_GENERAL_TRANSPORT 0x8020000BL
#define BG_E_ERROR_CONTEXT_QUEUE_MANAGER_NOTIFICATION 0x8020000CL
#define BG_E_DESTINATION_LOCKED          0x8020000DL
#define BG_E_VOLUME_CHANGED              0x8020000EL
#define BG_E_ERROR_INFORMATION_UNAVAILABLE 0x8020000FL
#define BG_E_NETWORK_DISCONNECTED        0x80200010L
#define BG_E_MISSING_FILE_SIZE           0x80200011L
#define BG_E_INSUFFICIENT_HTTP_SUPPORT   0x80200012L
#define BG_E_INSUFFICIENT_RANGE_SUPPORT  0x80200013L
#define BG_E_REMOTE_NOT_SUPPORTED        0x80200014L
#define BG_E_NEW_OWNER_DIFF_MAPPING      0x80200015L
#define BG_E_NEW_OWNER_NO_FILE_ACCESS    0x80200016L
#define BG_S_PARTIAL_COMPLETE            0x00200017L
#define BG_E_PROXY_LIST_TOO_LARGE        0x80200018L
#define BG_E_PROXY_BYPASS_LIST_TOO_LARGE 0x80200019L
#define BG_S_UNABLE_TO_DELETE_FILES      0x0020001AL
#define BG_E_INVALID_SERVER_RESPONSE     0x8020001BL
#define BG_E_TOO_MANY_FILES              0x8020001CL
#define BG_E_LOCAL_FILE_CHANGED          0x8020001DL
#define BG_E_ERROR_CONTEXT_REMOTE_APPLICATION 0x8020001EL
#define BG_E_SESSION_NOT_FOUND           0x8020001FL
#define BG_E_TOO_LARGE                   0x80200020L
#define BG_E_STRING_TOO_LONG             0x80200021L
#define BG_E_CLIENT_SERVER_PROTOCOL_MISMATCH 0x80200022L
#define BG_E_SERVER_EXECUTE_ENABLE       0x80200023L
#define BG_E_NO_PROGRESS                 0x80200024L
#define BG_E_USERNAME_TOO_LARGE          0x80200025L
#define BG_E_PASSWORD_TOO_LARGE          0x80200026L
#define BG_E_INVALID_AUTH_TARGET         0x80200027L
#define BG_E_INVALID_AUTH_SCHEME         0x80200028L
#define BG_E_FILE_NOT_FOUND              0x80200029L
#define BG_S_PROXY_CHANGED               0x0020002AL
#define BG_E_INVALID_RANGE               0x8020002BL
#define BG_E_OVERLAPPING_RANGES          0x8020002CL
#define BG_E_CONNECT_FAILURE             0x8020002DL
#define BG_E_CONNECTION_CLOSED           0x8020002EL
#define BG_E_BLOCKED_BY_POLICY           0x8020003EL
#define BG_E_INVALID_PROXY_INFO          0x8020003FL
#define BG_E_INVALID_CREDENTIALS         0x80200040L
#define BG_E_INVALID_HASH_ALGORITHM      0x80200041L
#define BG_E_RECORD_DELETED              0x80200042L
#define BG_E_COMMIT_IN_PROGRESS          0x80200043L
#define BG_E_DISCOVERY_IN_PROGRESS       0x80200044L
#define BG_E_UPNP_ERROR                  0x80200045L
#define BG_E_TEST_OPTION_BLOCKED_DOWNLOAD 0x80200046L
#define BG_E_PEERCACHING_DISABLED        0x80200047L
#define BG_E_BUSYCACHERECORD             0x80200048L
#define BG_E_TOO_MANY_JOBS_PER_USER      0x80200049L
#define BG_E_TOO_MANY_JOBS_PER_MACHINE   0x80200050L
#define BG_E_TOO_MANY_FILES_IN_JOB       0x80200051L
#define BG_E_TOO_MANY_RANGES_IN_FILE     0x80200052L
#define BG_E_VALIDATION_FAILED           0x80200053L
#define BG_E_MAXDOWNLOAD_TIMEOUT         0x80200054L
#define BG_S_OVERRIDDEN_BY_POLICY        0x00200055L
#define BG_E_TOKEN_REQUIRED              0x80200056L
#define BG_E_HTTP_ERROR_100              0x80190064L
#define BG_E_HTTP_ERROR_101              0x80190065L
#define BG_E_HTTP_ERROR_200              0x801900C8L
#define BG_E_HTTP_ERROR_201              0x801900C9L
#define BG_E_HTTP_ERROR_202              0x801900CAL
#define BG_E_HTTP_ERROR_203              0x801900CBL
#define BG_E_HTTP_ERROR_204              0x801900CCL
#define BG_E_HTTP_ERROR_205              0x801900CDL
#define BG_E_HTTP_ERROR_206              0x801900CEL
#define BG_E_HTTP_ERROR_300              0x8019012CL
#define BG_E_HTTP_ERROR_301              0x8019012DL
#define BG_E_HTTP_ERROR_302              0x8019012EL
#define BG_E_HTTP_ERROR_303              0x8019012FL
#define BG_E_HTTP_ERROR_304              0x80190130L
#define BG_E_HTTP_ERROR_305              0x80190131L
#define BG_E_HTTP_ERROR_307              0x80190133L
#define BG_E_HTTP_ERROR_400              0x80190190L
#define BG_E_HTTP_ERROR_401              0x80190191L
#define BG_E_HTTP_ERROR_402              0x80190192L
#define BG_E_HTTP_ERROR_403              0x80190193L
#define BG_E_HTTP_ERROR_404              0x80190194L
#define BG_E_HTTP_ERROR_405              0x80190195L
#define BG_E_HTTP_ERROR_406              0x80190196L
#define BG_E_HTTP_ERROR_407              0x80190197L
#define BG_E_HTTP_ERROR_408              0x80190198L
#define BG_E_HTTP_ERROR_409              0x80190199L
#define BG_E_HTTP_ERROR_410              0x8019019AL
#define BG_E_HTTP_ERROR_411              0x8019019BL
#define BG_E_HTTP_ERROR_412              0x8019019CL
#define BG_E_HTTP_ERROR_413              0x8019019DL
#define BG_E_HTTP_ERROR_414              0x8019019EL
#define BG_E_HTTP_ERROR_415              0x8019019FL
#define BG_E_HTTP_ERROR_416              0x801901A0L
#define BG_E_HTTP_ERROR_417              0x801901A1L
#define BG_E_HTTP_ERROR_449              0x801901C1L
#define BG_E_HTTP_ERROR_500              0x801901F4L
#define BG_E_HTTP_ERROR_501              0x801901F5L
#define BG_E_HTTP_ERROR_502              0x801901F6L
#define BG_E_HTTP_ERROR_503              0x801901F7L
#define BG_E_HTTP_ERROR_504              0x801901F8L
#define BG_E_HTTP_ERROR_505              0x801901F9L
#define BITS_MC_JOB_CANCELLED            0x80194000L
#define BITS_MC_FILE_DELETION_FAILED     0x80194001L
#define BITS_MC_FILE_DELETION_FAILED_MORE 0x80194002L
#define BITS_MC_JOB_PROPERTY_CHANGE      0x80194003L
#define BITS_MC_JOB_TAKE_OWNERSHIP       0x80194004L
#define BITS_MC_JOB_SCAVENGED            0x80194005L
#define BITS_MC_JOB_NOTIFICATION_FAILURE 0x80194006L
#define BITS_MC_STATE_FILE_CORRUPT       0x80194007L
#define BITS_MC_FAILED_TO_START          0x80194008L
#define BITS_MC_FATAL_IGD_ERROR          0x80194009L
#define BITS_MC_PEERCACHING_PORT         0x8019400AL
#define BITS_MC_WSD_PORT                 0x8019400BL
#endif
