/*+@@file@@----------------------------------------------------------------*//*!
 \file		GdiPlusStringFormat.h
 \par Description 
            Extension and update of headers for PellesC compiler suite.
 \par Project: 
            PellesC Headers extension
 \date		Created  on Sun Jul 17 15:37:01 2016
 \date		Modified on Sun Jul 17 15:37:01 2016
 \author	frankie
\*//*-@@file@@----------------------------------------------------------------*/

#ifndef _GDIPLUS_H
#define _GDIPLUS_H
#if __POCC__ >= 500
#pragma once
#endif
#include <fGdiPlusFlat.h>
#endif
