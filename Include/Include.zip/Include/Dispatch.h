/*+@@file@@----------------------------------------------------------------*//*!
 \file		Dispatch.h
 \par Description 
            Extension and update of headers for PellesC compiler suite.
 \par Project: 
            PellesC Headers extension
 \date		Created  on Wed Jul  6 13:39:06 2016
 \date		Modified on Wed Jul  6 13:39:06 2016
 \author	frankie
\*//*-@@file@@----------------------------------------------------------------*/

#if __POCC__ >= 500
#pragma once
#endif
#ifndef RC_INVOKED
#pragma message("WARNING: your code should #include oleauto.h instead of dispatch.h")
#endif
#include <oleauto.h>
