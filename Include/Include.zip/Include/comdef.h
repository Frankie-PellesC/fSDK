#ifndef  __cplusplus
#error Native Compiler support only available in C++ compiler
#endif
