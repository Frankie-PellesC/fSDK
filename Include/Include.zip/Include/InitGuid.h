/*+@@file@@----------------------------------------------------------------*//*!
 \file		InitGuid.h
 \par Description 
            Extension and update of headers for PellesC compiler suite.
 \par Project: 
            PellesC Headers extension
 \date		Created  on Sun Jul 17 00:44:04 2016
 \date		Modified on Sun Jul 17 00:44:04 2016
 \author	frankie
\*//*-@@file@@----------------------------------------------------------------*/

#if __POCC__ >= 500
#pragma once
#endif
#define INITGUID
#include <guiddef.h>
