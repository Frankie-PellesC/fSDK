/*+@@file@@----------------------------------------------------------------*//*!
 \file		DvObj.h
 \par Description 
            Extension and update of headers for PellesC compiler suite.
 \par Project: 
            PellesC Headers extension
 \date		Created  on Wed Jul  6 17:28:38 2016
 \date		Modified on Wed Jul  6 17:28:38 2016
 \author	frankie
\*//*-@@file@@----------------------------------------------------------------*/

#if __POCC__ >= 500
#pragma once
#endif
#ifndef RC_INVOKED
#pragma message("WARNING: your code should include ole2.h instead of dvobj.h")
#endif
#include <ole2.h>
