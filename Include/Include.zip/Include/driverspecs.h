/*+@@file@@----------------------------------------------------------------*//*!
 \file		driverspecs.h
 \par Description 
            Extension and update of headers for PellesC compiler suite.
 \par Project: 
            PellesC Headers extension
 \date		Created  on Wed Jul  6 14:31:16 2016
 \date		Modified on Wed Jul  6 14:31:16 2016
 \author	frankie
\*//*-@@file@@----------------------------------------------------------------*/

#ifndef DRIVERSPECS_H
#define DRIVERSPECS_H
#if __POCC__ >= 500
#pragma once
#endif
#error Annotations are not supported!
#endif
