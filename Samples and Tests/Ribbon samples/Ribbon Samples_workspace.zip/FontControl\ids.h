// *****************************************************************************
// * This is an automatically generated header file for UI Element definition  *
// * resource symbols and values. Please do not modify manually.               *
// *****************************************************************************

#pragma once

#define IDR_CMD_TAB1 10000  /* These comments are optional and are inserted into the header file. */ 
#define IDR_CMD_TAB1_LabelTitle_RESID 200
#define cmdGroup1 2 
#define cmdGroup1_SmallImages_RESID 201
#define cmdQat 3 
#define cmdFileMenu 4 
#define cmdMRUList 5 
#define cmdMRUList_LabelTitle_RESID 202
#define cmdExit 6 
#define cmdExit_LabelTitle_RESID 203
#define cmdExit_LargeImages_RESID 204
#define IDC_CMD_FONTCONTROL 7 
#define IDC_CMD_FONTCONTROL_Keytip_RESID 205
#define IDC_CMD_CONTEXTMAP 8  /* ContextualUI with mini toolbar */ 
