/*+@@file@@----------------------------------------------------------------*//*!
 \file		Application.h
 \par Description 
 \par  Status: 
 \par Project: 
 \date		Created  on Sun Oct 30 21:45:04 2016
 \date		Modified on Sun Oct 30 21:45:04 2016
 \author	
\*//*-@@file@@----------------------------------------------------------------*/
#include <UIRibbon.h>
#include "ribbonres.h"
#include "CommandHandler.h"

HRESULT ApplicationCreateInstance(IUIApplication** ppApplication, HWND hwnd);
