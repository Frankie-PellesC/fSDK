/*+@@file@@----------------------------------------------------------------*//*!
 \file		ContextPopup.h
 \par Description 
 \par  Status: 
 \par Project: 
 \date		Created  on Fri Oct 28 17:52:23 2016
 \date		Modified on Fri Oct 28 17:52:23 2016
 \author	
\*//*-@@file@@----------------------------------------------------------------*/

#pragma once
#include "resource.h"
