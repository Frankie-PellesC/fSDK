/*+@@file@@----------------------------------------------------------------*//*!
 \file		ContextUI.h
 \par Description 
 \par  Status: 
 \par Project: 
 \date		Created  on Fri Oct 28 17:53:16 2016
 \date		Modified on Fri Oct 28 17:53:16 2016
 \author	
\*//*-@@file@@----------------------------------------------------------------*/

#pragma once
#include <windows.h>

HRESULT ShowContextualUI(POINT *ptLocation, HWND hWnd);
