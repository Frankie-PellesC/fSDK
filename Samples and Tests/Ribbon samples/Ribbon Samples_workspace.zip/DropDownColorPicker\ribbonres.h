// *****************************************************************************
// * This is an automatically generated header file for UI Element definition  *
// * resource symbols and values. Please do not modify manually.               *
// *****************************************************************************

#pragma once

#define cmdTabHome 2 
#define cmdTabHome_LabelTitle_RESID 200
#define GroupDefaultDDCP 3 
#define GroupDefaultDDCP_LabelTitle_RESID 210
#define GroupCustomDDCP 4 
#define GroupCustomDDCP_LabelTitle_RESID 220
#define GroupColorGrid 5 
#define GroupColorGrid_LabelTitle_RESID 230
#define IDR_CMD_THEMEDDCP 6 
#define IDR_CMD_THEMEDDCP_LabelTitle_RESID 240
#define IDR_CMD_THEMEDDCP_LargeImages_RESID 241
#define IDR_CMD_HIGHLIGHTDDCP 7 
#define IDR_CMD_HIGHLIGHTDDCP_LabelTitle_RESID 250
#define IDR_CMD_HIGHLIGHTDDCP_LargeImages_RESID 251
#define IDR_CMD_STANDARDDDCP 8 
#define IDR_CMD_STANDARDDDCP_LabelTitle_RESID 260
#define IDR_CMD_STANDARDDDCP_LargeImages_RESID 261
#define IDR_CMD_UPDATE 9 
#define IDR_CMD_UPDATE_LabelTitle_RESID 270
#define IDR_CMD_UPDATE_TooltipTitle_RESID 271
#define IDR_CMD_UPDATE_TooltipDescription_RESID 272
#define IDR_CMD_UPDATE_LargeImages_RESID 273
#define IDR_CMD_CLEAR 10 
#define IDR_CMD_CLEAR_LabelTitle_RESID 280
#define IDR_CMD_CLEAR_TooltipTitle_RESID 281
#define IDR_CMD_CLEAR_TooltipDescription_RESID 282
#define IDR_CMD_CLEAR_LargeImages_RESID 283
#define InternalCmd2_LabelTitle_RESID 60001
