/*+@@file@@----------------------------------------------------------------*//*!
 \file		RibbonIIDs.c
 \par Description 
            We use this modulle to instanziate a copy of Ribbon GUIDs

 \par  Status: 
            
 \par Project: 
            
 \date		Created  on Sun Oct 30 15:41:42 2016
 \date		Modified on Sun Oct 30 15:41:42 2016
 \author	
\*//*-@@file@@----------------------------------------------------------------*/

#define INITGUID	//Define this to force instaziation of ribbon GUIDs
#include <RibbonIIDs.h>
