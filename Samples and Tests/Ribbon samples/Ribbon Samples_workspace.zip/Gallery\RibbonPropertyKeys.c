/*+@@file@@----------------------------------------------------------------*//*!
 \file		RibbonPropertyKeys.c
 \par Description 
            We use this modulle to instanziate a copy of UIPROPERTYKEYS for 
            ribbon
 \par  Status: 
 \par Project: 
 \date		Created  on Sun Oct 30 15:05:24 2016
 \date		Modified on Sun Oct 30 15:05:24 2016
 \author	
\*//*-@@file@@----------------------------------------------------------------*/

#define INITUIPROPERTYKEY 	//Defining this symbol an instance of Ribbon UIPROPERTYKEY's willl be instanziated
#include <UIRibbon.h>
