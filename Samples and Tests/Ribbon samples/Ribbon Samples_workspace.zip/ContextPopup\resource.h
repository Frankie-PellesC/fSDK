#pragma once
#define IDS_APP_TITLE           103
#define IDI_CONTEXTPOPUP        107
#define IDI_SMALL               108
#define IDS_CONTEXTPOPUP        109
