#define IDS_APP_TITLE            103
#define IDS_APP_CLASS            104
#define IDI_RIBBONAPP            107
#define IDI_SMALL                108
