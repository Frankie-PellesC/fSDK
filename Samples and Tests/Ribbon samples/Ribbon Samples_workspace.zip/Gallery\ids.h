// *****************************************************************************
// * This is an automatically generated header file for UI Element definition  *
// * resource symbols and values. Please do not modify manually.               *
// *****************************************************************************

#pragma once

#define cmdTabHome 2 
#define cmdTabHome_LabelTitle_RESID 200
#define cmdShapesGroup 3 
#define cmdShapesGroup_LabelTitle_RESID 210
#define cmdBorderGroup 4 
#define cmdBorderGroup_LabelTitle_RESID 220
#define cmdLayoutGroup 5 
#define cmdLayoutGroup_LabelTitle_RESID 230
#define IDR_CMD_SHAPES 6 
#define IDR_CMD_SHAPES_LabelTitle_RESID 240
#define IDR_CMD_SIZEANDCOLOR 7 
#define IDR_CMD_SIZEANDCOLOR_LabelTitle_RESID 250
#define IDR_CMD_SIZEANDCOLOR_LargeImages_96__RESID 251
#define IDR_CMD_SIZEANDCOLOR_LargeImages_120__RESID 252
#define IDR_CMD_SIZEANDCOLOR_LargeImages_144__RESID 253
#define IDR_CMD_SIZEANDCOLOR_LargeImages_192__RESID 254
#define IDR_CMD_BORDERSTYLES 8 
#define IDR_CMD_BORDERSTYLES_LabelTitle_RESID 260
#define IDR_CMD_BORDERSTYLES_LargeImages_96__RESID 261
#define IDR_CMD_BORDERSTYLES_LargeImages_120__RESID 262
#define IDR_CMD_BORDERSTYLES_LargeImages_144__RESID 263
#define IDR_CMD_BORDERSTYLES_LargeImages_192__RESID 264
#define IDR_CMD_BORDERSIZES 9 
#define IDR_CMD_BORDERSIZES_LabelTitle_RESID 270
#define IDR_CMD_LAYOUTS 10 
#define IDR_CMD_LAYOUTS_LabelTitle_RESID 280
#define IDR_CMD_SMALL 100 
#define IDR_CMD_SMALL_LabelTitle_RESID 290
#define IDR_CMD_SMALL_LargeImages_96__RESID 291
#define IDR_CMD_SMALL_LargeImages_120__RESID 292
#define IDR_CMD_SMALL_LargeImages_144__RESID 293
#define IDR_CMD_SMALL_LargeImages_192__RESID 294
#define IDR_CMD_MEDIUM 101 
#define IDR_CMD_MEDIUM_LabelTitle_RESID 300
#define IDR_CMD_MEDIUM_LargeImages_96__RESID 301
#define IDR_CMD_MEDIUM_LargeImages_120__RESID 302
#define IDR_CMD_MEDIUM_LargeImages_144__RESID 303
#define IDR_CMD_MEDIUM_LargeImages_192__RESID 304
#define IDR_CMD_LARGE 102 
#define IDR_CMD_LARGE_LabelTitle_RESID 310
#define IDR_CMD_LARGE_LargeImages_96__RESID 311
#define IDR_CMD_LARGE_LargeImages_120__RESID 312
#define IDR_CMD_LARGE_LargeImages_144__RESID 313
#define IDR_CMD_LARGE_LargeImages_192__RESID 314
#define IDR_CMD_RED 103 
#define IDR_CMD_RED_LabelTitle_RESID 320
#define IDR_CMD_RED_LargeImages_96__RESID 321
#define IDR_CMD_RED_LargeImages_120__RESID 322
#define IDR_CMD_RED_LargeImages_144__RESID 323
#define IDR_CMD_RED_LargeImages_192__RESID 324
#define IDR_CMD_GREEN 104 
#define IDR_CMD_GREEN_LabelTitle_RESID 330
#define IDR_CMD_GREEN_LargeImages_96__RESID 331
#define IDR_CMD_GREEN_LargeImages_120__RESID 332
#define IDR_CMD_GREEN_LargeImages_144__RESID 333
#define IDR_CMD_GREEN_LargeImages_192__RESID 334
#define IDR_CMD_BLUE 105 
#define IDR_CMD_BLUE_LabelTitle_RESID 340
#define IDR_CMD_BLUE_LargeImages_96__RESID 341
#define IDR_CMD_BLUE_LargeImages_120__RESID 342
#define IDR_CMD_BLUE_LargeImages_144__RESID 343
#define IDR_CMD_BLUE_LargeImages_192__RESID 344
#define InternalCmd2_LabelTitle_RESID 60001
