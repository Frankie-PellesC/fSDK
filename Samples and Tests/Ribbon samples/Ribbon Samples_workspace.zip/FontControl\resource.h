/*+@@file@@----------------------------------------------------------------*//*!
 \file		resource.h
 \par Description 
            Used by FontControl.rc.
 \par  Status: 
 \par Project: 
 \date		Created  on Tue Nov  1 22:57:41 2016
 \date		Modified on Tue Nov  1 22:57:41 2016
 \author	
\*//*-@@file@@----------------------------------------------------------------*/
#define IDS_APP_TITLE           100
#define IDI_FONTCONTROL         101
#define IDI_SMALL               102
#define IDC_FONTCONTROL         103
#define IDS_DEFAULTTEXTFONT     104
